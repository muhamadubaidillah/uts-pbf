<?php

require_once('core/public/index.php');
